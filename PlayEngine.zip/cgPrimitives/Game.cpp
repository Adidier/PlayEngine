#include "Game.h"
#include<iostream>
#include <glm.hpp>
#include <time.h>
#include <gtc\matrix_transform.hpp>
#include <gtc\type_ptr.hpp>


Game::Game()
{

}

Game::~Game()
{
}

void Game::Init()
{
	std::cout << " Menu Init" << std::endl;
	this->platform = Platform::GetPtr();
	this->manager = GameStateManager::GetPtr();
	resourceManager = ResourceManager::GetPtr();
	
	auto resourceManger = ResourceManager::GetPtr();
	resourceManger->Add(ResourceType::GUILine, "Line");

	resourceManger->Wait();
	player = new Player();

	LoadShaders();

	resourceManger->Load();
	m_image = (Graphic::GUILine*) resourceManager->GetElement("Line");
	srand(time(NULL));
	gui = new Graphic::GUI(m_image, player->GetCamera(), shaderManager);

	r = g = b = 0;
}

void Game::LoadShaders()
{
	shaderManager = ShaderManager::getPtr();
	shaderManager->initShader(player->GetCamera());
	shaderManager->LoadShaders("gui", "Assets/Shaders/gui.vert", "Assets/Shaders/gui.frag");
}

void Game::Draw()
{
	shaderManager->draw();

}

int abs(int n)
{
	return ((n > 0) ? n : (n * (-1)));
}

void Game::DrawLineDDA(float X0, float Y0, float X1, float Y1, int r,int g,int b)
{
	int dx = X1 - X0;
	int dy = Y1 - Y0;

	int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);

	float Xinc = dx / (float)steps;
	float Yinc = dy / (float)steps;

	float X = X0;
	float Y = Y0;
	for (int i = 0; i <= steps; i++)
	{
		m_image->PutPixel(X, Y, r, g, b, 255);
		X += Xinc;
		Y += Yinc;
	}
	m_image->Load();
}



void Game::CurveBezier(glm::vec2 v1, glm::vec2 v2, glm::vec2 v3, glm::vec2 v4, int r, int g, int b) {
	float u = 0;
	float x;
	float y;
	for (u = 0; u <= 1; u += 0.0001) {
		x = v4.x * (u * u * u) + 3 * v3.x * (u * u) * (1 - u) + 3 * v2.x * u * (1 - u) * (1 - u) + v1.x * pow(1 - u, 3);
		y = v4.y * (u * u * u) + 3 * v3.y * (u * u) * (1 - u) + 3 * v2.y * u * (1 - u) * (1 - u) + v1.y * pow(1 - u, 3);
		m_image->PutPixel(x, y, r, g, b, 255);
	}
	m_image->Load();
}


void Game::Update(unsigned int delta)
{
	//m_image->ClearImage();

	if (state == primitive::line && clicks.size() >1)
	{
		DrawLineDDA(clicks[0].x, clicks[0].y, clicks[1].x, clicks[1].y,r,g,b);
		clicks.clear();
		state = primitive::none;
	}
	else if (state == primitive::curve && clicks.size() > 4)
	{
		int size = clicks.size();
		CurveBezier(clicks[size - 4], clicks[size - 3], clicks[size - 2], clicks[size -1], r, g, b);
		clicks.clear();
		state = primitive::none;
	}

	//cuadrado linea
	DrawSquare(10,10,60,60);
	DrawLineDDA(13, 13, 54, 54);

	//cuadrado rojo
	DrawSquare(500, 10, 560, 60, 255, 0, 0);

	//cuadrado curva
	DrawSquare(70, 10, 130, 60);
	CurveBezier(glm::vec2(80, 55), glm::vec2(83, 20), glm::vec2(93,60), glm::vec2(120, 18));



	m_image->Load();
}

void Game::DrawSquare(int x1, int y1, int x2, int y2,int r,int g,int b)
{
	DrawLineDDA(x1, y1, x2, y1);
	DrawLineDDA(x1, y1, x1, y2);
	DrawLineDDA(x2, y1, x2, y2);
	DrawLineDDA(x1, y2, x2, y2);
	
	for (int i = x1 + 1; i < x2; ++i)
	{
		for (int j = y1 + 1; j < y2; ++j)
		{
			m_image->PutPixel(i, j, r, g, b, 255);
		}
	}
	m_image->Load();
}


void Game::DrawSquare(int x1, int y1, int x2, int y2)
{
	DrawLineDDA(x1, y1, x2, y1);
	DrawLineDDA(x1, y1, x1, y2);
	DrawLineDDA(x2, y1, x2, y2);
	DrawLineDDA(x1, y2, x2, y2);
}

bool Game::MouseInput(int x, int y, bool leftbutton)
{
	mousePosition.x = x;
	mousePosition.y = y;
	if (x != -1 || y != -1)
		player->GetCamera()->mouseControl(x, y);


	if (leftbutton && state == primitive::none)
	{
		//boton line
		if (mousePosition.x >= 10 && mousePosition.x <= 50)
		{
			if (mousePosition.y >= 10 && mousePosition.y <= 60)
			{
				state = primitive::line;
				return true;
			}
		}

		if (mousePosition.x >= 70 && mousePosition.x <= 130)
		{
			if (mousePosition.y >= 10 && mousePosition.y <= 60)
			{
				state = primitive::curve;
				return true;
			}
		}

		// color rojo
		if (mousePosition.x >= 500 && mousePosition.x <= 560)
		{
			if (mousePosition.y >= 10 && mousePosition.y <= 60)
			{
				r = 255;
				g = 0;
				b = 0;
				return true;
			}
		}
	}
	if (leftbutton)
	{
		clicks.push_back(glm::vec2(x, y));
	}

	return false;
}

bool Game::Input(std::map<int, bool> keys)
{
	player->GetCamera()->keyControl(keys, platform->GetDeltaTime());
	
	return false;
}

void Game::Close()
{
	std::cout << " Close Init" << std::endl;
}


/*

	glm::mat4 ViewTranslate = glm::translate(
		glm::mat4(1.0f),
		glm::vec3(0.0f, 0.0f, 0)
	);
	glm::mat4 rot = glm::rotate(ViewTranslate, angle_in_radians, glm::vec3(0, 0, 1));
	//glm::mat4 proy = glm::project(ViewTranslate, angle_in_radians, glm::vec3(0, 1, 0));
	angle_in_radians += .01;

	d = 5;
	proy[0][0] = d;
	proy[1][0] = 0;
	proy[2][0] = 0;
	proy[3][0] = 0;

	proy[0][1] = 0;
	proy[1][1] = d;
	proy[2][1] = 0;
	proy[3][1] = 0;

	proy[0][2] = 0;
	proy[1][2] = 0;
	proy[2][2] = 0;
	proy[3][2] = -1;

	proy[0][3] = 0;
	proy[1][3] = 0;
	proy[2][3] = 0;
	proy[3][3] = d;


	glm::vec2 points[8];
	int i = 0;
	for(auto v:vects)
	{
		glm::vec4 vecProy = (v * proy);
		vecProy /= vecProy.w;
		points[i] = vecProy *rot;
		i++;
	}

	DrawLineDDA(points[0].x + 400, points[0].y + 400, points[1].x + 400, points[1].y + 400);
	DrawLineDDA(points[1].x + 400, points[1].y + 400, points[2].x + 400, points[2].y + 400);
	DrawLineDDA(points[2].x + 400, points[2].y + 400, points[3].x + 400, points[3].y + 400);
	DrawLineDDA(points[3].x + 400, points[3].y + 400, points[0].x + 400, points[0].y + 400);

	DrawLineDDA(points[0].x + 400, points[0].y + 400, points[4].x + 400, points[4].y + 400);
	DrawLineDDA(points[1].x + 400, points[1].y + 400, points[5].x + 400, points[5].y + 400);
	DrawLineDDA(points[2].x + 400, points[2].y + 400, points[6].x + 400, points[6].y + 400);
	DrawLineDDA(points[3].x + 400, points[3].y + 400, points[7].x + 400, points[7].y + 400);


	DrawLineDDA(points[4].x + 400, points[4].y + 400, points[5].x + 400, points[5].y + 400);
	DrawLineDDA(points[5].x + 400, points[5].y + 400, points[6].x + 400, points[6].y + 400);
	DrawLineDDA(points[6].x + 400, points[6].y + 400, points[7].x + 400, points[7].y + 400);

*/