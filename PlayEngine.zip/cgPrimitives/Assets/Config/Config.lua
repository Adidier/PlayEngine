ScreenHeight = 1024
ScreenWidth = 1024
Fullscreen = false
Name = "Last chance"
Assets = "assets/"
States = "states/"
Debug = true
UpKey = 87
DownKey = 83
LeftKey = 65
RightKey = 68


 function f (x, y)
	print (x)
	return (x*y)
  end
