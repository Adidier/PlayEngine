#pragma once
#include "Base/GameState.h"
#include "Base/GameStateManager.h"
#include "Graphic/Mesh.h"
#include "Graphic/Shader.h"
#include "Base/ShaderManager.h"
#include "Base/ResourceManager.h"
#include "Graphic/Model.h"
#include "Graphic/Skybox.h"
#include "Player.h"
#include "Graphic/GUI.h"
#include "Graphic/GUILine.h"
#include<vector>

class Game : public GameState
{
private:
	Platform* platform = nullptr;
	GameStateManager* manager = nullptr;
	ResourceManager* resourceManager = nullptr;
	ShaderManager* shaderManager = nullptr; 
	Player *player = nullptr;
	Graphic::GUI* gui = nullptr;
	Graphic::GUILine* m_image = nullptr;
	float angle_in_radians = 0;


	glm::vec4 vects[8];
	float d = 0;
	glm::mat4 proy;
	glm::vec2 point0;
	glm::vec2 point1;
	glm::vec2 point2;
	glm::vec2 point3;

	enum primitive
	{
		none,
		line,
		curve,
		cicle

	};

	glm::vec2 mousePosition;
	primitive state;
	std::vector< glm::vec2> clicks;
	int r, g, b;

	void CurveBezier(glm::vec2 v1, glm::vec2 v2, glm::vec2 v3, glm::vec2 v4, int r = 0, int g = 0, int b = 0);

public:
	Game();
	~Game();
	void Init() override;
	void Draw() override;
	bool Input(std::map<int, bool> keys) override;
	bool MouseInput(int x, int y, bool leftbutton);
	void Update(unsigned int delta) override;
	void DrawSquare(int x1, int y1, int x2, int y2);
	void DrawSquare(int x1, int y1, int x2, int y2, int r, int g, int b);
	void Close() override;
	void LoadShaders();
	void LoadModels(const std::map<std::string, std::string>& models);
	void DrawLineDDA(float X0, float Y0, float X1, float Y1, int r = 0, int g = 0, int b = 0);

};
